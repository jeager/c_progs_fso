double perimeter(Triangle triangle);
double distance_two_points(Point a, Point b);
int is_valid(Triangle triangle);
double triangle_area(Triangle triangle);