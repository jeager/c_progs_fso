Triangle create_triangle();
void print_triangle(Triangle t);
