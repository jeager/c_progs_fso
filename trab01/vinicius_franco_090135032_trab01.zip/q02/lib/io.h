int check_existing_options(char *argv[]);
int *create_numbers_array(int size);
int *populate_array(int *array, int size);
void print_array(int *array, int size);